import java.util.Scanner;
class CalculatorApp
{
public static void main(string[] args)
{
int num1,num2,res=0;
Scanner numbers=new Scanner(System.in);
Scanner numbers=new Scanner(System.in);
String op;
System.out.println("enter the 1st number");
num1=numbers.nextInt();
assert(num1>0)"the number should be greater than 0.";
System.out.println("enter 2nd number");
num2=numbers.next.Int();
assert(num2>0):"the number should be greater than 0.";
System.out.println("enter the operator");
op=operator.nextLine();
assert((op.equals("+))||(op.equals("-"))||(op.eguals("*"))||(op.equals("/"))):"the operator is not valid.";
if(op.equals("+"))
{
res=num1+num2;
}
if(op.equals("-"))
{
if(num1>num2)
{
res=num1-num2;
}
else
{
res=num2-num1;
}
else if(op.equals("*"))
{
res=num1*num2;
}
else if(op.equals("/"))
{
res=num1/num2;
}
else
{
System.out.println("wrong operator");
}
System.out.println("the result is"+res);
}
}
